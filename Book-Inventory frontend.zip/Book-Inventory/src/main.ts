import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { PublisherComponent } from './app/publisher/publisher.component';
import { HomeComponent } from './app/home/home.component';
import { BookComponent } from './app/book/book.component';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
