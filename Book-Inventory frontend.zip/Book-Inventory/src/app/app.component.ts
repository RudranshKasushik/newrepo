// src/app/app.component.ts
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink, RouterOutlet } from '@angular/router';
import { AuthenticationService } from './login/authentication.service';
import { LoginService } from './login/login.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Book Inventory Management';
  sidebarOpen = false;
  isLoggedIn = false;
  isAdmin = false;
  userId: number | null = null;
  user:any={};
  roleno:number| null=null;

  constructor(private authService: AuthenticationService,private route : ActivatedRoute,private loginServ :LoginService) {
    // this.userId= Number
  }

  ngOnInit(): void {
    this.isLoggedIn = this.authService.isUserLoggedIn();
    this.userId = this.authService.getUserId();
    console.log(this.userId);
    if(this.userId){
    this.fetchUser(this.userId);
  }
  }

  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }

  logout(): void {
    this.authService.logout();
    this.isLoggedIn = false;
    this.userId = null;
  }


  fetchUser(userid:number): void {
    this.loginServ.getUserById(userid).subscribe(
      (response: any) => {
        this.user = response;
        this.roleno = response.permrole.rolenumber;
        const rno = this.roleno;
        console.log(this.roleno);
        if (this.roleno=== 4){
          this.isAdmin =true;
        }
        // this.authService.saveUserRoleNumber(this.roleno);
      },
      (error: any) => {
        console.error('Error fetching user:', error);
      }
    );
  }

}
