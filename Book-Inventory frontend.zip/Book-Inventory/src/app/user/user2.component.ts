import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { UsersService } from "./user.service";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-users',
  templateUrl: './user2.component.html',
  styleUrls: ['./user2.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [UsersService]
})
export class User2Component implements OnInit {
  users: any = null; // Initialize as null to check *ngIf condition
  public roleNumbers = [1, 2, 3, 4];
  errorMessage: string | undefined;
  userId: number = 0;

  constructor(private usersService: UsersService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.userId = Number(this.route.snapshot.paramMap.get('userid'));
    console.log('User ID from route:', this.userId);
    if (this.userId) {
      this.getUserById(this.userId);
    }
  }

  // Fetch user details by ID
  public getUserById(userid: number) {
    console.log('getting user');
    this.usersService.getUserById(userid).subscribe(
      (response) => {
        console.log("this is response", response);
        if (response) { // Directly checking response, change based on actual response structure
          this.users = response; // Ensure correct assignment
          console.log('User details retrieved', this.users);
        } else {
          alert('User not found!');
        }
      },
      (error) => {
        console.error('Error fetching user:', error);
        alert('Error fetching user!');
      }
    );
  }
}
