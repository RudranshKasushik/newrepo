import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  private apiUrl = 'http://localhost:8090/api/users';  // Backend API URL

  constructor(private http: HttpClient) {}

  // Add a new user
  addUser(user: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(`${this.apiUrl}/add`, user, { headers });
  }

  // Get user by ID
  getUserById(userId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/getuser/${userId}`);
  }

  // Update first name by user ID
  updateFirstName(userId: number, firstName: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/firstname/${userId}`, firstName);
  }

  // Update last name by user ID
  updateLastName(userId: number, lastName: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/lastname/${userId}`, lastName);
  }

  // Update phone number by user ID
  updatePhoneNumber(userId: number, phoneNumber: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/phonenumber/${userId}`, phoneNumber);
  }

  // User login authentication
  authenticate(user: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, user);
  }
}
