import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { UsersService } from "./user.service";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-users',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [UsersService]
})
export class UserComponent implements OnInit {

  users: any = {
    userid: 0, 
    lastname: "", 
    firstname: "", 
    phonenumber: "", 
    username: "", 
    password: "", 
    permrole: { rolenumber: null }  // Ensure permrole is initialized as an object
  };
  public roleNumbers = [1, 2, 3, 4]; // Array to hold valid role numbers
  router: any;
  errorMessage: string | undefined;
  userId: number = 0;

  constructor(private usersService: UsersService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.userId = Number(this.route.snapshot.paramMap.get('userid'));
    console.log('User ID from route:', this.userId); // Check if this is a valid ID
    if (this.userId) {
      this.getUserById(this.userId);
    }
  }
  
  // Add a new user
  public addUser() {
    this.usersService.addUser(this.users).subscribe(
      (response) => {
        console.log('User added successfully:', response.status);
        alert('User added successfully!');
      },
      (error) => {
        console.error('Error adding user:', error);
        alert('Error adding user!');
      }
    );
  }

  // Fetch user details by ID
  public getUserById(userid: number) {
    console.log('getting user')
    this.usersService.getUserById(userid).subscribe(
      (response) => {
                  console.log("this is response",response);
        if (response.body) {

          this.users = response.body;
          console.log('User details retrieved', this.users);
        } else {
          alert('User not found!');
        }
      },
      (error) => {
        console.error('Error fetching user:', error);
        alert('Error fetching user!');
      }
    );
  }

  // Update the phone number
  public updatePhoneNumber() {
    const body = this.users.phonenumber;
    this.usersService.updatePhoneNumber(this.users.userid, this.users.phonenumber).subscribe(
      (response) => {
        console.log('Phone number updated successfully:', response.status);
        alert('Phone number updated successfully!');
      },
      (error) => {
        console.error('Error updating phone number:', error);
        alert('Error updating phone number!');
      }
    );
  }

  // Update the last name
  public updateLastName() {
    const body = this.users.lastname;
    this.usersService.updateLastName(this.users.userid, this.users.lastname).subscribe(
      (response) => {
        console.log('Last name updated successfully:', response.status);
        alert('Last name updated successfully!');
      },
      (error) => {
        console.error('Error updating last name:', error);
        alert('Error updating last name!');
      }
    );
  }

  // Update the first name
  public updateFirstName() {
    const body = this.users.firstname;
    this.usersService.updateFirstName(this.users.userid, this.users.firstname).subscribe(
      (response) => {
        console.log('First name updated successfully:', response.status);
        alert('First name updated successfully!');
      },
      (error) => {
        console.error('Error updating first name:', error);
        alert('Error updating first name!');
      }
    );
  }
}
