import { Component } from '@angular/core';
import { InventoryService } from './inventory.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
 
@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css'],
  standalone: true,
  imports: [FormsModule, CommonModule]
})
export class InventoryComponent {
  // Form Data for Adding Inventory
  inventory = {
    inventoryid: null,
    book: { isbn: '' },
    bookcondition: { ranks: null }
  };
 
  // Variables for Fetching and Updating Inventory
  searchId: number = 0;
  fetchedInventory: any = null;
  updateId: number = 0;
  updatePurchased: boolean = false;
 
  message: string = ''; // Success message
  error: string = '';   // Error message
 
  activeForm: string | null = null; // To track the active form
 
  constructor(private inventoryService: InventoryService) {}
 
  // Set Active Form
  setActiveForm(form: string) {
    this.activeForm = form;
    this.message = '';
    this.error = '';
    this.fetchedInventory = null;
  }
 
  // Add Inventory
  addInventory() {
    this.message = '';
    this.error = '';
    this.inventoryService.addInventory(this.inventory).subscribe(
      (response) => {
        this.message = response.message;
      },
      (error) => {
        if (error.status === 409) {
          this.error = 'Error: Inventory already exists.';
        } else if (error.status === 404) {
          if (error.error.includes('Book not found')) {
            this.error = 'Error: Book ISBN not found.';
          } else if (error.error.includes('Book condition not found')) {
            this.error = 'Error: Book condition rank not found.';
          } else {
            this.error = 'Error: Resource not found.';
          }
        } else {
          this.error = 'An unexpected error occurred. Please try again.';
        }
      }
    );
  }
 
  fetchInventoryById() {
    this.message = '';
    this.error = '';
    this.inventoryService.getInventoryById(this.searchId).subscribe(
      (data) => {
        this.fetchedInventory = data; // This updates the fetchedInventory object with the fetched data
      },
      (error) => {
        this.error = 'Error: Inventory not found.';
        this.fetchedInventory = null; // Reset the fetched data if error occurs
      }
    );
  }
 
  // Update Purchased Status
  updatePurchasedStatus() {
    this.message = '';
    this.error = '';
    this.inventoryService.updatePurchasedStatus(this.updateId, this.updatePurchased).subscribe(
      (response) => {
        this.message = 'Purchased status updated successfully!';
      },
      (error) => {
        if (error.status === 404) {
          this.error = 'Error: Inventory ID not found.';
        } else {
          this.error = 'Error: Unable to update purchased status.';
        }
      }
    );
  }
}
 