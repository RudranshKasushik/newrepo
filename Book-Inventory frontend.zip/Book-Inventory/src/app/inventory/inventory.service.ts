import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private baseUrl = 'http://localhost:8090/api/inventory'; // Update the port if needed

  constructor(private http: HttpClient) {}

  addInventory(inventory: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/post`, inventory).pipe(
      catchError(this.handleError)
    );
  }

  getInventoryById(inventoryId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/update/purchased/${inventoryId}`).pipe(
      catchError(this.handleError)
    );
  }

  updatePurchasedStatus(inventoryId: number, purchased: boolean): Observable<any> {
    return this.http.put(`${this.baseUrl}/${inventoryId}`, null, {
      params: { purchased: purchased.toString() }
    }).pipe(
      catchError(this.handleError)
    );
  }

  getInventoryDetailsByIsbn(isbn: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/inventory-details/${isbn}`).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
