import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
// import { environment } from 'src/environments/environment'; // Make sure the API endpoint is correct

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  private apiUrl = 'http://localhost:8090/api/users/add'; // URL of your backend API

  constructor(private httpClient: HttpClient) {}

  // Method to register a new user
  addUser(user: any): Observable<any> {
    return this.httpClient.post(this.apiUrl, user, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    });
  }
}
