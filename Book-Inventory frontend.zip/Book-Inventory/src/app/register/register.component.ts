import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
// import { User } from './user.model';  // Import the User model
// import { UserService } from './user.service';  // Your service to handle HTTP requests
import { RegistrationService } from './register.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  imports: [CommonModule, FormsModule,ReactiveFormsModule],
})
export class RegistrationComponent {
        [x: string]: any;
        user = {
          lastname: '',
          firstname: '',
          phonenumber: '',
          username: '',
          password: '',
          permrole: { rolenumber: 1 } // Adjust this to your role logic
        };
      
        message = '';
        success = false;
      
        constructor(private userService: RegistrationService,private router: Router) {}
      
        addUser() {
          this.userService.addUser(this.user).subscribe(
            (response) => {
              this.success = true;
              this.message = response.message;
            },
            (error) => {
              this.success = false;
              this.message = error.error.message;
            }
          );
        }

        goToSignIn() {
            this.router.navigate(['/login']);  // Replace '/login' with your actual login route
          }
      }