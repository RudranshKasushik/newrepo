import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
 
@Component({
  selector: 'app-about', // Use the convention for the selector
  templateUrl: './about.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  styleUrls: ['./about.component.css'],
})
export class AboutComponent {
 
 
  learnMore() {
    alert('Thank you for your interest! More details will be added soon.');
  }
}