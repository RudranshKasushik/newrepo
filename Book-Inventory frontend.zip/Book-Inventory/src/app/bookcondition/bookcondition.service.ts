import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';import { Bookcondition } from './bookcondition.model';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
 
 
@Injectable({
  providedIn: 'root'
})
export class BookconditionService {
 
  private apiUrl = 'http://localhost:8090/api/bookcondition';
 
  constructor(private http: HttpClient) {}
 
  addBookcondition(bookcondition: Bookcondition): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/post`, bookcondition).pipe(
      catchError((error) => {
        let errorMessage = 'Error adding book condition';
        //  if the error status is 400 and parse the backend error message
        if (error.status === 409 ) {
          errorMessage = `Bookcondition with  this rank already exists.`;
        }
        return throwError(() => new Error(errorMessage));
      })
    );
  }
 
 
  getBookconditionByRanks(ranks: number): Observable<Bookcondition> {
    return this.http.get<Bookcondition>(`${this.apiUrl}/update/price/${ranks}`).pipe(
      catchError((error) => {
        let errorMessage = 'Error fetching book condition';
        if (error.status === 404) {
          errorMessage = `Bookcondition with rank ${ranks} not found.`;
        }
        return throwError(() => new Error(errorMessage));
      })
    );
  }
 
  updatePrice(ranks: number, price: number): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${ranks}?price=${price}`, {}).pipe(
      catchError((error) => {
        let errorMessage = 'Error updating price';
        if (error.status === 404) {
          errorMessage = `Bookcondition with rank ${ranks} not found.`;
        }
        return throwError(() => new Error(errorMessage));
      })
    );
  }
 
  updateDescription(ranks: number, description: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/description/${ranks}?description=${description}`, {}).pipe(
      catchError((error) => {
        let errorMessage = 'Error updating description';
        if (error.status === 404) {
          errorMessage = `Bookcondition with rank ${ranks} not found.`;
        }
        return throwError(() => new Error(errorMessage));
      })
    );
  }
 
  updateFullDescription(ranks: number, fullDescription: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/fullDescription/${ranks}?fullDescription=${fullDescription}`, {}).pipe(
      catchError((error) => {
        let errorMessage = 'Error updating full description';
        if (error.status === 404) {
          errorMessage = `Bookcondition with rank ${ranks} not found.`;
        }
        return throwError(() => new Error(errorMessage));
      })
    );
  }
 
}