import { Component, OnInit } from '@angular/core';
import { BookconditionService } from './bookcondition.service';
import { Bookcondition } from './bookcondition.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
 
@Component({
  selector: 'app-bookcondition',
  templateUrl: './bookcondition.component.html',
  styleUrls: ['./bookcondition.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class BookconditionComponent implements OnInit {
 
 
  bookcondition: Bookcondition | null = null;
  ranks: number | undefined;
  description: string = '';
  fulldescription: string = '';
  price: number | undefined;
  message: string = '';
  errorMessage: string = '';
  successMessage: string = '';
  currentAction: string = '';
 
  constructor(private bookconditionService: BookconditionService) {}
 
  ngOnInit(): void {}
 
 
  setAction(action: string): void {
    this.currentAction = action;
    this.resetFormFields();
  }
  // for resetting the data
  resetFormFields(): void {
    this.ranks = undefined;
    this.price = undefined;
    this.description = '';
    this.fulldescription = '';
    this.bookcondition = null;
    this.message = '';
    this.errorMessage = '';
    this.successMessage = '';
  }
 
 
 
  addBookcondition(): void {
    const newBookcondition: Bookcondition = {
      ranks: this.ranks!,
      price: this.price!,
      description: this.description,
      fulldescription: this.fulldescription,
    };
 
    this.bookconditionService.addBookcondition(newBookcondition).subscribe(
      () => {
        this.successMessage = `Bookcondition with rank ${newBookcondition.ranks} successfully added!`;
        this.errorMessage = '';
       
      },
      (error) => {
        this.errorMessage = error.message || 'Error adding book condition';
        this.successMessage = '';
      }
    );
  }
 
  getBookcondition(): void {
    if (this.ranks) {
      this.bookconditionService.getBookconditionByRanks(this.ranks).subscribe(
        (data) => {
          this.bookcondition = data;
          this.successMessage = `Bookcondition with rank ${this.ranks} fetched successfully!`;
          this.errorMessage = '';
        },
        (error) => {
          this.errorMessage = error.message || `Error fetching book condition with rank ${this.ranks}`;
          this.successMessage = '';
        }
      );
    }
  }
 
  updatePrice(): void {
    if (this.ranks && this.price) {
      this.bookconditionService.updatePrice(this.ranks, this.price).subscribe(
        () => {
          this.successMessage = `Price updated successfully for rank ${this.ranks}!`;
          this.errorMessage = '';
        },
        (error) => {
          this.errorMessage = error.message || `Error updating price for rank ${this.ranks}`;
          this.successMessage = '';
        }
      );
    }
  }
 
  updateDescription(): void {
    if (this.ranks && this.description) {
      this.bookconditionService.updateDescription(this.ranks, this.description).subscribe(
        () => {
          this.successMessage = `Description updated successfully for rank ${this.ranks}!`;
          this.errorMessage = '';
        },
        (error) => {
          this.errorMessage = error.message || `Error updating description for rank ${this.ranks}`;
          this.successMessage = '';
        }
      );
    }
  }
 
  updateFullDescription(): void {
    if (this.ranks && this.fulldescription) {
      this.bookconditionService.updateFullDescription(this.ranks, this.fulldescription).subscribe(
        () => {
          this.successMessage = `Full description updated successfully for rank ${this.ranks}!`;
          this.errorMessage = '';
        },
        (error) => {
          this.errorMessage = error.message || `Error updating full description for rank ${this.ranks}`;
          this.successMessage = '';
        }
      );
    }
  }
 
}