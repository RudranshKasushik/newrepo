export  interface Bookcondition {
    ranks: number;
    description: string;
    fulldescription: string;
    price: number;
  }