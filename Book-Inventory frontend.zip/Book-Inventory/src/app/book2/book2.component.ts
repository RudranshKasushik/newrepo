import { Component } from '@angular/core';
import { BookService } from '../book/book.service';
import { Book } from '../book/book.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  selector: 'app-book2',
  templateUrl: './book2.component.html',
  styleUrls: ['./book2.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink],
})
export class Book2Component {

  book: Book = {isbn: '',title: '',description: '',edition: '',
  category: {id: 0,description: ''},
  publisher: {id: 0,name: '',city: '', state: '' }};

bookList: Book[]=[];
constructor(private bookService: BookService) { }
singleBook: Book | null = null;
titleSearch: Book | null = null;
categorySearch: Book[]=[];
publisherSearch: Book[]=[];
isbnSearch: string = '';
updatedBook: Book | null = null;
searchTerm: any;  // Stores the search term entered
searchCriteria: any;

  public updateBookTitle(isbn: string, newTitle: string): void {
    if (isbn && newTitle) {
      this.bookService.updateBookTitle(isbn, newTitle).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book title updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book title:', error);
        }
      );
    }
  }

  // Update book description
  public updateBookDescription(isbn: string, newDesc: string): void {
    if (isbn && newDesc) {
      this.bookService.updateBookDescription(isbn, newDesc).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book description updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book description:', error);
        }
      );
    }
  }

  // Update book category
  public updateBookCategory(isbn: string, newCat: number): void {
    if (isbn && newCat !== null) {
      this.bookService.updateBookCategory(isbn, newCat).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book category updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book category:', error);
        }
      );
    }
  }

  // Update book edition
  public updateBookEdition(isbn: string, newEdition: string): void {
    if (isbn && newEdition) {
      this.bookService.updateBookEdition(isbn, newEdition).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book edition updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book edition:', error);
        }
      );
    }
  }


  public addBook(): void {
    this.bookService.addBook(this.book).subscribe();
  }



  // public addBook(): void {
  //   if (this.book.isbn && this.book.title && this.book.description) {
  //     this.bookService.addBook(this.book).subscribe(
  //       (response) => {
  //         if (response.code === 'POSTSUCCESS') {
  //           console.log('Book added successfully:', response);
  //           // Optionally, reset the form or show success message
  //           this.resetForm();
  //         } else {
  //           console.error('Error adding book:', response.message);
  //           // Optionally, show an error message
  //         }
  //       },
  //       (error) => {
  //         console.error('Error occurred while adding book:', error);
  //       }
  //     );
  //   } else {
  //     console.log('Please fill in all required fields.');
  //   }
  // }

  private resetForm(): void {
    this.book = { 
      isbn: '', 
      title: '', 
      description: '', 
      edition: '', 
      category: { id: 0, description: '' },
      publisher: { id: 0, name: '', city: '', state: '' }
    };
  }



}
