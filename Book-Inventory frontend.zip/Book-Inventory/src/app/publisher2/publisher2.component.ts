import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterOutlet, RouterLink } from "@angular/router";
import { Publisher } from "../book/book.model";
import { PublisherService } from "../publisher/publisher.service";
import { HttpResponse } from "@angular/common/http";

@Component({
  selector: 'app-book2',
  templateUrl: './publisher2.component.html',
  styleUrls: ['./publisher2.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, RouterOutlet, RouterLink],
})
export class Publisher2Component {
  publisher: Publisher = { id: 0, name: '', city: '', state: '' };
  publisherList: Publisher[] = [];
  publisherById: Publisher | null = null;
  publisherByName: Publisher | null = null;
  publishersByCity: Publisher[] = [];
  publishersByState: Publisher[] = [];
  searchTerm: any;
  searchCriteria: any;

  constructor(private publisherService: PublisherService) {}

  public updatePublisherName(id: string, newName: string) {
    const publisherId = parseInt(id, 10);
    if (!publisherId) {
      alert('Please enter a valid Publisher ID.');
      return;
    }
    if (!newName) {
      alert('Please enter a new Name.');
      return;
    }
    this.publisherService.updatePublisherName(publisherId, newName).subscribe(
      (response: HttpResponse<Publisher>) => {
        this.publisherById = response.body;
        console.log('Publisher updated name:', this.publisherById);
      },
      (error) => {
        console.error('Error updating publisher name:', error);
        alert('Error updating publisher name.');
      }
    );
  }

  public updatePublisherCity(id: string, newCity: string) {
    const publisherId = parseInt(id, 10);
    if (!publisherId) {
      alert('Please enter a valid Publisher ID.');
      return;
    }
    if (!newCity) {
      alert('Please enter a new City.');
      return;
    }
    this.publisherService.updatePublisherCity(publisherId, newCity).subscribe(
      (response: HttpResponse<Publisher>) => {
        this.publisherById = response.body;
        console.log('Publisher updated city:', this.publisherById);
      },
      (error) => {
        console.error('Error updating publisher city:', error);
        alert('Error updating publisher city.');
      }
    );
  }

  public updatePublisherStateByState(state: string, requestData: any) {
    if (!state) {
      alert('Please enter a State.');
      return;
    }
    this.publisherService.updatePublisherStateByState(state, requestData).subscribe(
      (response: HttpResponse<Publisher>) => {
        this.publisherById = response.body;
        console.log('Publisher updated state:', this.publisherById);
      },
      (error) => {
        console.error('Error updating publisher state:', error);
        alert('Error updating publisher state.');
      }
    );
  }

  public addPublisher() {
    if (!this.publisher.name || !this.publisher.city || !this.publisher.state) {
      alert('Please fill in all fields.');
      return;
    }
    this.publisherService.addPublisher(this.publisher).subscribe(
      (response) => {
        console.log('Publisher added:', response);
      },
      (error) => {
        console.error('Error adding publisher:', error);
        alert('Error adding publisher.');
      }
    );
  }
}
