import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { BookService } from "../book/book.service";
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
    selector: 'home', // name of the component element tag
    standalone:true,
    imports: [RouterLink,RouterOutlet,RouterOutlet],
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css'],
  })
  export class HomeComponent {
    // imageUrl: string = 'assets/img/homebookimg.jpg';
  
    constructor(private router: Router, private bookService: BookService) {}
  
    getAllBooks(event: Event) {
      event.preventDefault();
      this.bookService.getAllBooks();
    }
  
    showPublisher(): void {
      this.router.navigate(['/publisher']);
    }
  }