import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { Author } from './author.model';  
 
@Injectable({
  providedIn: 'root'
})
export class AuthorService {
  private apiUrl = 'http://localhost:8090/api/author';  
 
  constructor(private http: HttpClient) {}
 
  // Get Author by ID
  getAuthorById(authorId: number): Observable<Author> {
    return this.http.get<Author>(`${this.apiUrl}/${authorId}`);
  }
 
  // Get Authors by First Name
  getAuthorsByFirstName(firstname: string): Observable<Author[]> {
    return this.http.get<Author[]>(`${this.apiUrl}/firstname/${firstname}`);
  }
 
  // Get Authors by Last Name
  getAuthorsByLastName(lastname: string): Observable<Author[]> {
    return this.http.get<Author[]>(`${this.apiUrl}/lastname/${lastname}`);
  }
 
 
  // Get Books by Author ID
  getBooksByAuthorId(authorId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/books/${authorId}`);
  }
}