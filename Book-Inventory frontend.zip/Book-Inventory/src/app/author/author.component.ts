import { Component } from '@angular/core';
import { AuthorService } from './author.service';
import { Author } from './author.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
 
@Component({
  selector: 'author-crud',
  templateUrl: './author.component.html',
  styleUrls: ['./author.component.css'],
  imports: [FormsModule, CommonModule, HttpClientModule],
  providers: [AuthorService]
})
export class AuthorComponent {
  author = {
    id: null,
    firstname: '',
    lastname: '',
    photo: ''
  };
 
  // Search variables
  firstNameSearchTerm: string = '';
  lastNameSearchTerm: string = '';
  authorIdToSearch: number | any = null;
  authorIdToGetBooks: number | any = null;
 
  // Response variables
  authorById: Author | null = null;
  authorsByFirstName: Author[] = [];
  authorsByLastName: Author[] = [];
  booksByAuthor: any[] = [];
 
  // Variable to track which action is selected
  selectedAction: string = '';
 
  constructor(private authorService: AuthorService) {}
 
  // Method to change the action
  selectAction(action: string) {
    this.selectedAction = action;
    this.clearResults(); // Clear previous results
  }
 
  // Method to clear results when changing actions
  clearResults() {
    this.authorById = null;
    this.authorsByFirstName = [];
    this.authorsByLastName = [];
    this.booksByAuthor = [];
  }
 
  // Perform the action based on selectedAction
  performAction() {
    switch (this.selectedAction) {
      case 'getById':
        this.getAuthorById(this.authorIdToSearch);
        break;
      case 'getByFirstName':
        this.getAuthorsByFirstName(this.firstNameSearchTerm);
        break;
      case 'getByLastName':
        this.getAuthorsByLastName(this.lastNameSearchTerm);
        break;
      case 'getBooksByAuthor':
        this.getBooksByAuthorId(this.authorIdToGetBooks);
        break;
      default:
        alert('Please select a valid search option.');
        break;
    }
  }
 
  // Get author By Id
  getAuthorById(authorId: number) {
    if (authorId) {
      this.authorService.getAuthorById(authorId).subscribe(
        (author: Author) => {
          if (author) {
            this.authorById = author;
          } else {
            alert('Author Id not found.');
          }
        },
        (error) => {
          console.error('Error fetching author by ID:', error);
          alert('Please provide a valid Author ID.');
        }
      );
    } else {
      alert('Please enter Author Id');
    }
  }
 
  // Get Authors by First Name
  getAuthorsByFirstName(firstName: string) {
    if (firstName && firstName.trim() !== '') {
      this.authorService.getAuthorsByFirstName(firstName).subscribe(
        (authors: Author[]) => {
          this.authorsByFirstName = authors;
        },
        (error) => {
          console.error('Error fetching authors by first name:', error);
          alert('Please provide a valid First Name.');
        }
      );
    } else {
      alert('Please enter First Name');
    }
  }
 
  // Get Authors by Last Name
  getAuthorsByLastName(lastName: string) {
    if (lastName && lastName.trim() !== '') {
      this.authorService.getAuthorsByLastName(lastName).subscribe(
        (authors: Author[]) => {
          this.authorsByLastName = authors;
        },
        (error) => {
          console.error('Error fetching authors by last name:', error);
          alert('Please provide a valid Last Name.');
        }
      );
    } else {
      alert('Please enter Last Name');
    }
  }
 
  // Get Books by Author ID
  getBooksByAuthorId(authorId: number) {
    if (authorId) {
      this.authorService.getBooksByAuthorId(authorId).subscribe(
        (books: any[]) => {
          this.booksByAuthor = books;
        },
        (error) => {
          console.error('Error fetching books by author ID:', error);
          alert('Please provide a valid Author ID.');
        }
      );
    } else {
      alert('Please provide a Author ID.');
    }
  }
}