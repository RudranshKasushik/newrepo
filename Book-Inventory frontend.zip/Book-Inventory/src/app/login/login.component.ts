// src/app/components/login/login.component.ts
import { Component } from "@angular/core";
import { LoginService } from "./login.service";
import { Router, RouterLink, RouterOutlet } from "@angular/router";
import { AuthenticationService } from "./authentication.service";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule, RouterOutlet, RouterLink],
})
export class LoginComponent {
  constructor(
    private loginService: LoginService,
    private router: Router,
    private authService: AuthenticationService  // Inject AuthenticationService
  ) {}

  public authenticate(form: any): void {
    // Send login details to the backend
    this.loginService.authenticate({
      "username": form.value.username,
      "password": form.value.password
    }).subscribe(
      (response: any) => {
        console.log('Backend response:', response);
        if (response.message === 'Valid User') {
          // Set the login state to true and save the userid when login is successful
          const body = response.userid;
          this.authService.login(body);
          this.router.navigate(['/home']).then(() => {
            window.location.reload();});

        } else {
          alert('Invalid username or password! Please register.');
        }
      },
      (error: any) => {
        if (error.status === 401) {
          alert('Invalid username or password! Please register.');
          this.router.navigate(['/registration']);
        } else {
          alert('An error occurred while processing your request. Please try again later.');
        }
      }
    );
  }

  public gotoRegistrationView() {
    this.router.navigate(['/register']);
  }
}
