// src/app/components/login/authentication.service.ts
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private loggedIn = false;
  private userId: number | null = null;
  private roleNumberKey = 'roleNumber';

  login(userId: number): void {
    this.loggedIn = true;
    this.userId = userId;
    localStorage.setItem('loggedIn', 'true');
    localStorage.setItem('userId', userId.toString());
  }

  logout(): void {
    this.loggedIn = false;
    this.userId = null;
    localStorage.removeItem('loggedIn');
    localStorage.removeItem('userId');
  }

  isUserLoggedIn(): boolean {
    return this.loggedIn || localStorage.getItem('loggedIn') === 'true';
  }

  getUserId(): number | null {
    const storedUserId = localStorage.getItem('userId');
    return storedUserId ? +storedUserId : null;
  }

  saveUserRoleNumber(roleNumber: number): void {
    localStorage.setItem(this.roleNumberKey, roleNumber.toString());
  }

  getUserRoleNumber(): number | null {
    const roleNumber = localStorage.getItem(this.roleNumberKey);
    return roleNumber ? parseInt(roleNumber, 10) : null;
  }
}
