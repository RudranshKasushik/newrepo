import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PurchaseLogService } from './purchaselog.service';
 
@Component({
  selector: 'app-purchaselog',
  templateUrl: './purchaselog.component.html',
  styleUrls: ['./purchaselog.component.css'],
  imports: [CommonModule, FormsModule],
})
export class PurchaseLogComponent {
  // Variables to control UI modes
  fetchLogsMode: boolean = false;
  updateMode: boolean = false;
  isAdmin: boolean = false; // Property to control admin visibility
 
  // Input values
  enteredUserId: number = 0;
  updateUserId: number = 0;
  newInventoryId: number = 0;
 
  // Data storage for logs
  purchaseLogs: any[] = [];
  updatedInventoryLog: any = null;
 
  // Error message handling
  errorMessage: string = '';
 
  constructor(private purchaseLogService: PurchaseLogService) {}
 
  // Method to activate Fetch Logs mode
  activateFetchLogsMode() {
    this.fetchLogsMode = true;
    this.updateMode = false;
    this.errorMessage = '';
    this.purchaseLogs = [];
  }
 
  // Method to activate Update Inventory mode
  activateUpdateMode() {
    this.updateMode = true;
    this.fetchLogsMode = false;
    this.errorMessage = '';
    this.updatedInventoryLog = null;
  }
 
  // Update inventory using the service
  updateInventory() {
    if (this.updateUserId && this.newInventoryId) {
      this.purchaseLogService.updateInventory(this.updateUserId, this.newInventoryId).subscribe({
        next: (data) => {
          // Map updated log to include userId and inventoryId directly for display
          this.updatedInventoryLog = {
            userId: data.id.userId,
            inventoryId: data.id.inventoryId,
          };
          this.errorMessage = '';
        },
        error: (err) => {
          this.errorMessage = 'Failed to update inventory. Please try again.';
        },
      });
    } else {
      this.errorMessage = 'Please enter valid User ID and New Inventory ID.';
    }
  }
}