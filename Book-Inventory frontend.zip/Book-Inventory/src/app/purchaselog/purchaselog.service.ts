import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class PurchaseLogService
{
  private apiUrl = 'http://localhost:8090/api/purchaselog';
 
  constructor(private http: HttpClient) {}
 
  // Add Purchase Log
  addPurchaseLog(userId: number, inventoryId: number): Observable<any> {
    const purchaseLogDTO = { userId, inventoryId };
    return this.http.post(`${this.apiUrl}/post`, purchaseLogDTO);
  }
 
  // Update Inventory ID for a User
  updateInventory(userId: number, newInventoryId: number): Observable<any> {
    const purchaseLogDTO = { userId, newInventory: newInventoryId };
    return this.http.put(`${this.apiUrl}/update/inventoryid/${userId}`, purchaseLogDTO);
  }
}