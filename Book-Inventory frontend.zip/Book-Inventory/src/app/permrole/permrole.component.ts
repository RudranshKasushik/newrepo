import { Component } from '@angular/core';
import { PermroleService } from './permrole.service';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
 
@Component({
  selector: 'app-permrole',
  templateUrl: './permrole.component.html',
  styleUrls: ['./permrole.component.css'],
  standalone:true,
  imports: [ FormsModule,CommonModule]
 
})
export class PermroleComponent {
  formType: string = ''; // To toggle between forms
  roleNumber: number = 0;
  addPermroleData = { rolenumber: 0, permrole: '' };
  updateRoleNumber: number = 0;
  updatePermroleData = { permrole: '' };
  fetchedPermrole: any = null;
  responseMessage: string = '';
 
  constructor(private permroleService: PermroleService) {}
 
  // Show selected form
  showForm(type: string) {
    this.formType = type;
    this.responseMessage = '';
    this.fetchedPermrole = null;
  }
 
  // Add Permrole
  addPermrole() {
    this.permroleService.addPermrole(this.addPermroleData).subscribe(
      (response) => {
        this.responseMessage = 'Permrole added successfully!';
      },
      (error) => {
        this.responseMessage = error.error.message || 'Error adding permrole!';
      }
    );
  }
 
 // Get Permrole
getPermrole() {
    this.permroleService.getPermrole(this.roleNumber).subscribe(
      (response) => {
        if (response) {
          this.fetchedPermrole = response;
          this.responseMessage = ''; // Clear any previous error message
        } else {
          this.fetchedPermrole = null;
          this.responseMessage = 'Permrole with this Role Number does not exist!';
        }
      },
      (error) => {
        // Show error message if the role number does not exist
        this.fetchedPermrole = null;
        this.responseMessage = error.error.message || 'Permrole with this Role Number does not exist!';
      }
    );
  }
 
 
   // **Update Permrole method**
   updatePermrole() {
    this.permroleService.updatePermrole(this.updateRoleNumber, this.updatePermroleData).subscribe(
      (response) => {
        // ✅ Handle plain text response correctly
        this.responseMessage = response ? response : 'Permrole updated successfully!';
      },
      (error) => {
        // ❌ Handle error properly
        this.responseMessage = error.error || 'Error updating permrole!';
      }
    );
  }
 
}