import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class PermroleService {
  private baseUrl = 'http://localhost:8090/api/permrole';
 
  constructor(private http: HttpClient) {}
 
  // Add Permrole
  addPermrole(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/post`, data);
  }
 
  // Get Permrole by role number
getPermrole(roleNumber: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/update/permrole/${roleNumber}`);
  }
 
 
 // **Update Permrole by Role Number**
 updatePermrole(roleNumber: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${roleNumber}`, data, { responseType: 'text' }); // 👈 Handle plain text response
  }
}