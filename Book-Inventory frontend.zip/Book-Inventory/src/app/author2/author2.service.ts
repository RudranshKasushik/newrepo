import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { Author } from './author2.model';  
 
@Injectable({
  providedIn: 'root'
})
export class AuthorService {
  private apiUrl = 'http://localhost:8091/api/author';  
 
  constructor(private http: HttpClient) {}
 
 
    private errorHandler(error: HttpErrorResponse): Observable<any> {
    if (error.status == 0) {
        alert("Client side error");
    }
    else if(error.status == 201){
        alert("Author Added Successfully")
    }
    else if(error.status == 200){
        alert("Author Name Modified Successfully")
    }
    else {
        alert(
            "Error message: " + error.message + "\n" +
            "Error name: " + error.name + "\n" +
            "Error status: " + error.status
        );
    }
    return throwError(() => new Error(error.message));
}
 
 // Add Author
 addAuthor(author: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/post`, author);
  }
   // Update Author First Name
   updateAuthorFirstName(authorId: number, firstname: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/firstname/${authorId}`, firstname).pipe(catchError(this.errorHandler));
  }
 
  // Update Author Last Name
  updateAuthorLastName(authorId: number, lastName: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/lastname/${authorId}`, lastName).pipe(catchError(this.errorHandler));
  }
}