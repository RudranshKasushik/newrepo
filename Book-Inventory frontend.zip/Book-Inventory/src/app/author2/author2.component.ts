import { Component } from '@angular/core';
import { AuthorService } from './author2.service';
import { Author } from './author2.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
 
@Component({
  selector: 'author2-crud',
  templateUrl: './author2.component.html',
  styleUrls: ['./author2.component.css'],
  imports: [FormsModule, CommonModule, HttpClientModule],
  providers: [AuthorService]
})
export class Author2Component {
  currentAction: string = 'add';  // Default action is 'add'
 
  // Model for adding an author
  author = {
    id: null,
    firstname: '',
    lastname: '',
    photo: ''
  };
 
  // Model for updating first and last name
  authorIdToUpdateFirstName: number | any = null;
  authorIdToUpdateLastName: number | any = null;
  newFirstName: string = '';
  newLastName: string = '';
 
  constructor(private authorService: AuthorService) {}
 
  // Method to change the action (Add, Update First Name, Update Last Name)
  setAction(action: string) {
    this.currentAction = action;
  }
 
  // Add Author
  addAuthor() {
    if (this.author.id && this.author.firstname && this.author.lastname) {
      this.authorService.addAuthor(this.author).subscribe(
        response => {
          console.log('Author added:', response);
          alert('Author added successfully!');
        },
        error => {
          console.error('Error adding author:', error);
          alert('Error adding author. Please try again later.');
        }
      );
    } else {
      alert('Please fill in all fields (ID, First Name, Last Name) to add an author.');
    }
  }
 
  // Update Author First Name
  updateAuthorFirstName() {
    if (this.authorIdToUpdateFirstName && this.newFirstName) {
      this.authorService.updateAuthorFirstName(this.authorIdToUpdateFirstName, this.newFirstName).subscribe(
        response => {
          console.log('Author first name updated:', response);
          alert('Author first name updated successfully!');
        },
        error => {
          console.error('Error updating author first name:', error);
        }
      );
    } else {
      alert('Please provide Author ID and New First Name.');
    }
  }
 
  // Update Author Last Name
  updateAuthorLastName() {
    if (this.authorIdToUpdateLastName && this.newLastName) {
      this.authorService.updateAuthorLastName(this.authorIdToUpdateLastName, this.newLastName).subscribe(
        response => {
          console.log('Author last name updated:', response);
        },
        error => {
          console.error('Error updating author last name:', error);
        }
      );
    } else {
      alert('Please provide Author ID and New Last Name.');
    }
  }
}