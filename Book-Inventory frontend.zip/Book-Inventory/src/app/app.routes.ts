import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { BookComponent } from './book/book.component';
import { Component } from '@angular/core';
import { PublisherComponent } from './publisher/publisher.component';
import { CardComponent } from './card/card.component';
import { AboutComponent } from './about/about.component';
import { Book2Component } from './book2/book2.component';
import { Publisher2Component } from './publisher2/publisher2.component';
import { AdminComponent } from './admin/admin.component';
import { AuthorComponent } from './author/author.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './register/register.component';
import { CartComponent } from './cart/cart.component';
import { StateComponent } from './state/state.component';
import { ReviewerComponent } from './reviewer/reviewer.component';
import { InventoryComponent } from './inventory/inventory.component';
import { UserComponent } from './user/user.component';
import { PurchaseLog2Component } from './purchaselog2/purchaselog2.component';
import { Author2Component } from './author2/author2.component';
import { CategoryComponent } from './category/category.component';
import { BookconditionComponent } from './bookcondition/bookcondition.component';
import { PermroleComponent } from './permrole/permrole.component';
import { User2Component } from './user/user2.component';
export const routes: Routes = [
    {path:'',redirectTo:'/home',pathMatch:'full'},
    { path: 'book', component: BookComponent },
    {component:BookComponent , path :'book/:userid'},
    {component:HomeComponent,path:'home'},
    {component:PublisherComponent,path:'publisher'},
    {component:CardComponent,path:'card/:isbn'},
    { path: 'card/:isbn/:userId', component: CardComponent },
    {path:'cart/:userid/:inventoryid', component: CartComponent},
    {component:CartComponent,path:'cart/:userid'},
    {component:AboutComponent,path:'aboutus'},
    {component:Book2Component,path:'book2'},
    {component:Publisher2Component, path:'publisher2'},
    {component:AdminComponent, path:'admin'},
    {component:AuthorComponent, path:'author'},
    {component:LoginComponent, path:'login'},
    {component:RegistrationComponent, path:'register'},
    {component: StateComponent, path:'state'},
    {component: ReviewerComponent, path:'reviewer'},
    {component:InventoryComponent, path:'inventory'},
    {component: UserComponent, path:'user/:userid'},
    {component:User2Component,path:'user2/:userid'},
    {component:UserComponent,path:'users'},
    {component:PurchaseLog2Component, path:'orders/:userid'},
    {component:Author2Component, path : 'author2'},
    {component:CategoryComponent,path:'category'},
    {component:BookconditionComponent,path:'condition'},
    {component:PermroleComponent,path:'permrole'}
    // {component: InventoryComponent, path: 'inventory'}
];
