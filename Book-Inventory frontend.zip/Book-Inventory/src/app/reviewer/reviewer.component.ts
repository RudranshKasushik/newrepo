import { Component } from '@angular/core';
import { ReviewerService } from './reviewer.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
 
@Component({
  selector: 'reviewer-crud',
  templateUrl: './reviewer.component.html',
  styleUrls: ['./reviewer.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  providers: [ReviewerService],
})
export class ReviewerComponent {
  reviewer: any = { reviewerId: null, name:'', employedby:''};
  reviewerList: any = [];
  errorMessage: string = '';
 
  constructor(private reviewerService: ReviewerService) {}
 
  // Add Reviewer
public addReviewer() {
  this.reviewerService.addReviewer(this.reviewer).subscribe(
    (response) => {
      console.log('Reviewer Added:', response);
      alert('Reviewer added successfully!'); // Success alert
      this.getReviewerById(); // Refresh the reviewer list after adding the reviewer
    },
    (error) => {
      this.errorMessage = 'Error adding reviewer';
      alert(this.errorMessage); // Error alert
    }
  );
}
 
  // Get Reviewer by ID
  public getReviewerById() {
    if (!this.reviewer.reviewerId) {
      this.errorMessage = 'Please Provide Reviewer ID';
      alert(this.errorMessage); // Error alert
      return;
    }
   
    this.reviewerService.getReviewerById(this.reviewer.reviewerId).subscribe(
      (response) => {
        if (response.body) {
          this.reviewer = response.body;
          console.log('Reviewer Found:', this.reviewer);
        } else {
          this.errorMessage = 'Reviewer not found.';
          alert(this.errorMessage); // Error alert
        }
      },
      (error) => {
        this.errorMessage = 'Reviewer not found.';
        alert(this.errorMessage); // Error alert
        console.error(error);
      }
    );
  }
 
  // Update Reviewer Name
  updateReviewer() {
    if (this.reviewer.reviewerId && this.reviewer.name) {
      this.reviewerService.updateReviewerName(this.reviewer.reviewerId, this.reviewer).subscribe(
        (response) => {
          console.log('Reviewer updated:', response);
          alert('Reviewer name updated successfully!'); // Success alert
          this.getReviewerById(); // Optionally refresh the reviewer list
        },
        (error) => {
          this.errorMessage = 'Reviwer Id not found';
          alert(this.errorMessage); // Error alert
          console.error(error);
        }
      );
    } else {
      this.errorMessage = 'Please provide both reviewer ID and name.';
      alert(this.errorMessage); // Error alert
    }
  }
 
  // Update Reviewer EmployedBy
  public updateReviewerEmployment() {
    if (this.reviewer.reviewerId ) {
      this.reviewerService.updateReviewerEmployment(this.reviewer.reviewerId, this.reviewer).subscribe(
        (response) => {
          console.log('Reviewer employment status updated:', response);
          alert('Reviewer employment status updated successfully!'); // Success alert
          this.getReviewerById(); // Optionally refresh the reviewer details
        },
        (error) => {
          this.errorMessage = 'Reviewer Id not found';
          alert(this.errorMessage); // Error alert
          console.error(error);
        }
      );
    } else {
      this.errorMessage = 'Please provide both reviewer ID and employment status.';
      alert(this.errorMessage); // Error alert
    }
  }
}