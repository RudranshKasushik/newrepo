import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root',
})
export class ReviewerService {
  private static url: string = 'http://localhost:8090/api/reviewer';
  constructor(private httpClient: HttpClient) {}
 
  // Add New Reviewer
  public addReviewer(reviewer: any): Observable<HttpResponse<any>> {
    return this.httpClient.post(ReviewerService.url + '/post', reviewer, { observe: 'response' });
  }
 
  // Get Reviewer by Reviewer ID
  public getReviewerById(reviewerId: number): Observable<HttpResponse<any>> {
    return this.httpClient.get<any>(ReviewerService.url + '/' + reviewerId, { observe: 'response' });
  }
 
  // Update Reviewer Name by ID
  public updateReviewerName(reviewerId: number, reviewer: any): Observable<HttpResponse<any>> {
    return this.httpClient.put(ReviewerService.url + '/name/' + reviewerId, reviewer, { observe: 'response' });
  }
 
  // Update Reviewer's Employment Status by ID
  public updateReviewerEmployment(reviewerId: number, reviewer: any): Observable<HttpResponse<any>> {
    return this.httpClient.put(ReviewerService.url + '/employedby/' + reviewerId, reviewer, { observe: 'response' });
  }
}