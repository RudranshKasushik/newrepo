import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { PublisherService } from "./publisher.service";
import { Publisher } from "./publisher.model";
import { HttpResponse } from "@angular/common/http";
import { FormsModule } from "@angular/forms";

@Component({
    selector: 'publisher-crud',
    templateUrl: './publisher.component.html',
    standalone: true,
    imports: [CommonModule, FormsModule],
    styleUrls: ['./publisher.component.css'],
    providers: [PublisherService]
})
export class PublisherComponent {
    publisher: Publisher = { id: 0, name: '', city: '', state: '' };
    publisherList: Publisher[] = [];
    publisherById: Publisher | null = null;
    publisherByName: Publisher | null = null;
    publishersByCity: Publisher[] = [];
    publishersByState: Publisher[] = [];
    searchTerm: any;  
    searchCriteria: any;
    constructor(private publisherService: PublisherService) { }

    private clearResults() {
        this.publisherList = [];
        this.publisherById = null;
        this.publisherByName = null;
        this.publishersByCity = [];
        this.publishersByState = [];
    }

    public getAllPublisher() {
        this.clearResults();
        this.publisherService.getAllPublishers().subscribe(
            (response: HttpResponse<Publisher[]>) => {
                this.publisherList = response.body ?? [];
            },
            (error) => {
                console.error('Error fetching all publishers:', error);
                alert('Error fetching all publishers.');
            }
        );
    }

    public getPublisherById(id: number) {
        if (!id) {
            alert('Please enter a Publisher ID.');
            return;
        }
        this.clearResults();
        this.publisherService.getPublisherById(id).subscribe(
            (response: HttpResponse<Publisher>) => {
                this.publisherById = response.body;
                console.log('Publisher by ID:', this.publisherById);
            },
            (error) => {
                console.error('Error fetching publisher by ID:', error);
                alert('Error fetching publisher by ID.');
            }
        );
    }

    public getPublisherByName(name: string) {
        if (!name) {
            alert('Please enter a Publisher Name.');
            return;
        }
        this.clearResults();
        this.publisherService.getPublisherByName(name).subscribe(
            (response: HttpResponse<Publisher>) => {
                this.publisherByName = response.body;
                console.log('Publisher by Name:', this.publisherByName);
            },
            (error) => {
                console.error('Error fetching publisher by Name:', error);
                alert('Error fetching publisher by Name.');
            }
        );
    }

    public getPublisherByCity(city: string) {
        if (!city) {
            alert('Please enter a City.');
            return;
        }
        this.clearResults();
        this.publisherService.getPublisherByCity(city).subscribe(
            (response: HttpResponse<Publisher[]>) => {
                this.publishersByCity = response.body ?? [];
                console.log('Publishers by City:', this.publishersByCity);
            },
            (error) => {
                console.error('Error fetching publishers by City:', error);
                alert('Error fetching publishers by City.');
            }
        );
    }

    public getPublisherByState(state: string) {
        if (!state) {
            alert('Please enter a State.');
            return;
        }
        this.clearResults();
        this.publisherService.getPublisherByState(state).subscribe(
            (response: HttpResponse<Publisher[]>) => {
                this.publishersByState = response.body ?? [];
                console.log('Publishers by State:', this.publishersByState);
            },
            (error) => {
                console.error('Error fetching publishers by State:', error);
                alert('Error fetching publishers by State.');
            }
        );
    }

    public updatePublisherName(id: number, newName: string) {
        if (!id) {
            alert('Please enter a Publisher ID.');
            return;
        }
        if (!newName) {
            alert('Please enter a new Name.');
            return;
        }
        this.publisherService.updatePublisherName(id, newName).subscribe(
            (response: HttpResponse<Publisher>) => {
                this.publisherById = response.body;
                console.log('Publisher updated name:', this.publisherById);
            },
            (error) => {
                console.error('Error updating publisher name:', error);
                alert('Error updating publisher name.');
            }
        );
    }

    public updatePublisherCity(id: number, newCity: string) {
        if (!id) {
            alert('Please enter a Publisher ID.');
            return;
        }
        if (!newCity) {
            alert('Please enter a new City.');
            return;
        }
        this.publisherService.updatePublisherCity(id, newCity).subscribe(
            (response: HttpResponse<Publisher>) => {
                this.publisherById = response.body;
                console.log('Publisher updated city:', this.publisherById);
            },
            (error) => {
                console.error('Error updating publisher city:', error);
                alert('Error updating publisher city.');
            }
        );
    }

    public updatePublisherStateByState(state: string, requestData: any) {
        if (!state) {
            alert('Please enter a State.');
            return;
        }
        this.publisherService.updatePublisherStateByState(state, requestData).subscribe(
            (response: HttpResponse<Publisher>) => {
                this.publisherById = response.body;
                console.log('Publisher updated state:', this.publisherById);
            },
            (error) => {
                console.error('Error updating publisher state:', error);
                alert('Error updating publisher state.');
            }
        );
    }

    public addPublisher() {
        if (!this.publisher.name || !this.publisher.city || !this.publisher.state) {
            alert('Please fill in all fields.');
            return;
        }
        this.publisherService.addPublisher(this.publisher).subscribe(
            (response) => {
                console.log('Publisher added:', response);
            },
            (error) => {
                console.error('Error adding publisher:', error);
                alert('Error adding publisher.');
            }
        );
    }

    getCombinedPublishers(): Publisher[] {
        const combined: Publisher[] = [];

        if (this.publisherList.length > 0) {
            combined.push(...this.publisherList);
        }

        if (this.publisherById) {
            combined.push(this.publisherById);
        }

        if (this.publisherByName) {
            combined.push(this.publisherByName);
        }

        if (this.publishersByCity.length > 0) {
            combined.push(...this.publishersByCity);
        }

        if (this.publishersByState.length > 0) {
            combined.push(...this.publishersByState);
        }

        return combined;
    }

    public onSearchCriteriaChange(searchTerm:any): void {
        this.clearResults();
        switch (this.searchCriteria) {
            case 'Name':
                this.getPublisherByName(this.searchTerm);
                break;
            case 'City':
                this.getPublisherByCity(this.searchTerm);
                break;
            case 'Id':
                this.getPublisherById(this.searchTerm);
                break;
            case 'State':
                this.getPublisherByState(this.searchTerm);
                break;
            default:
                this.getAllPublisher();
        }
    }

}
