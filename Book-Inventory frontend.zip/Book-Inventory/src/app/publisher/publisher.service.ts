import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse } from "@angular/common/http";
import { Observable } from "rxjs";
import { Publisher } from "./publisher.model";

@Injectable({
    providedIn:"root"
})

export class PublisherService {
    private static url:string = "http://localhost:8090/publisher";
    constructor(private httpClient: HttpClient){}

    public getAllPublishers():Observable<HttpResponse<Publisher[]>>{
        return this.httpClient.get<Publisher[]>(PublisherService.url+"/allpublisher",{observe:"response"});
    }

// Method to get a publisher by ID
    public getPublisherById(id: number): Observable<HttpResponse<Publisher>> {
    // return this.httpClient.get<Publisher>(PublisherService.url+"/byId"+id);
        return this.httpClient.get<Publisher>(`${PublisherService.url}/byId/${id}`, { observe: 'response' });
    }


    // public getPublisherById(id: number): Observable<HttpResponse<Publisher>> {
    //     return this.httpClient.get<Publisher>(PublisherService.url+"/byId"+id);
    // }

  // Method to get a publisher by name
  public getPublisherByName(name: string): Observable<HttpResponse<Publisher>> {
    return this.httpClient.get<Publisher>(`${PublisherService.url}/name/${name}`, { observe: 'response' });
  }

  // Method to get publishers by city
  public getPublisherByCity(city: string): Observable<HttpResponse<Publisher[]>> {
    return this.httpClient.get<Publisher[]>(PublisherService.url+"/city/"+city, { observe: 'response' });
  }
    // public getEmployeeById(empid:number):Observable<any>{
    //     return this.httpClient.get(EmployeeService.url+"/"+empid);
    // }
  // Method to get publishers by state
  public getPublisherByState(state: string): Observable<HttpResponse<Publisher[]>> {
    return this.httpClient.get<Publisher[]>(`${PublisherService.url}/state/${state}`, { observe: 'response' });
  }

  // Method to update publisher's name
  public updatePublisherName(id: number, newName: string): Observable<HttpResponse<Publisher>> {
    return this.httpClient.put<Publisher>(`${PublisherService.url}/updateName/${id}`, newName, { observe: 'response' });
  }

  // Method to update publisher's city
  public updatePublisherCity(id: number, newCity: string): Observable<HttpResponse<Publisher>> {
    return this.httpClient.put<Publisher>(`${PublisherService.url}/updateCity/${id}`, newCity, { observe: 'response' });
  }

  // Method to update publisher's state by state
  public updatePublisherStateByState(state: string, requestData: any): Observable<HttpResponse<Publisher>> {
    return this.httpClient.put<Publisher>(`${PublisherService.url}/updateStateByState/${state}`, requestData, { observe: 'response' });
  }

  public addPublisher(publisher: Publisher): Observable<HttpResponse<Publisher>> {
    return this.httpClient.post<Publisher>(PublisherService.url+"/addPublisher", publisher, { observe: 'response' });
  }
    //   public addPublisher(Publisher:publisher) :Observable<HttpResponse<Publisher>{
    //     return this.httpClient.post<Publisher>(PublisherService.url,publisher);
    // }

}