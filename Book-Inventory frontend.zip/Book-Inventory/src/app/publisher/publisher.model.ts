export interface Publisher {
    id: number;
    name: string;
    city: string;
    state: string;
  }
  