import { HttpClient, HttpResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, Subject, catchError } from "rxjs";
import { Book } from "./book.model";



@Injectable({
    providedIn:"root"
})

export class BookService {
    private static url:string = "http://localhost:8090/book";
    constructor(private httpClient: HttpClient){}

    public getAllBooks():Observable<HttpResponse<Book[]>>{
        return this.httpClient.get<Book[]>(BookService.url+"/allbooks",{observe:"response"});
    }


//     private getAllBooksSource = new Subject<void>(); // This will emit events
//   getAllBooks$ = this.getAllBooksSource.asObservable(); // Observable to subscribe to

//   triggerGetAllBooks() {
//     this.getAllBooksSource.next(); // Emit an event to trigger getAllBooks
//   }

    public getBookById(isbn: string): Observable<HttpResponse<Book>> {
        return this.httpClient.get<Book>(`${BookService.url}/byId/${isbn}`, { observe: 'response' });
      }
    
      // Get book by title
      public getBookByTitle(title: string): Observable<HttpResponse<Book>> {
        return this.httpClient.get<Book>(`${BookService.url}/title/${title}`, { observe: 'response' });
      }
    
      // Get books by category ID
      public getBookByCategory(category: number): Observable<HttpResponse<Book[]>> {
        return this.httpClient.get<Book[]>(`${BookService.url}/category/${category}`, { observe: 'response' });
      }
    
      // Get books by publisher ID
      public getBookByPublisher(publisherid: number): Observable<HttpResponse<Book[]>> {
        return this.httpClient.get<Book[]>(`${BookService.url}/publisher/${publisherid}`, { observe: 'response' });
      }
    
      // Update book title
      public updateBookTitle(isbn: string, newTitle: string): Observable<HttpResponse<Book>> {
        return this.httpClient.put<Book>(`${BookService.url}/updateTitle/${isbn}`, newTitle, { observe: 'response' });
      }
    
      // Update book description
      public updateBookDescription(isbn: string, newDesc: string): Observable<HttpResponse<Book>> {
        return this.httpClient.put<Book>(`${BookService.url}/updateDesc/${isbn}`, newDesc, { observe: 'response' });
      }
    
      // Update book category
      public updateBookCategory(isbn: string, newCat: number): Observable<HttpResponse<Book>> {
        return this.httpClient.put<Book>(`${BookService.url}/updateCategory/${isbn}`, newCat, { observe: 'response' });
      }
    
      // Update book edition
      public updateBookEdition(isbn: string, newEdition: string): Observable<HttpResponse<Book>> {
        return this.httpClient.put<Book>(`${BookService.url}/updateEdition/${isbn}`, newEdition, { observe: 'response' });
      }
    
      // Update book publisher
    //   public updateBookPublisher(isbn: string, newPublisherDTO: Publisher): Observable<HttpResponse<Book>> {
    //     return this.httpClient.put<Book>(`${BookService.url}/updatePublisher/${isbn}`, newPublisherDTO, { observe: 'response' });
    //   }


    // addBook(book: Book): Observable<any> {
    //   return this.httpClient.post<Book>(`${BookService.url}/addbook`, book,{observe:'response'});
    // }

    public addBook(book: Book): Observable<HttpResponse<Book>> {
      return this.httpClient.post<Book>(BookService.url + "/addbook", book, { observe: 'response' }).pipe(
        catchError((error) => {
          console.error('Error adding book:', error);
          throw error; // or handle it as needed
        })
      );
    }
    
}