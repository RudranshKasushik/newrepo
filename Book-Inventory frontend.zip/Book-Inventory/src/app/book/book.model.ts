export interface Category {
    id: number;
    description: string;
  }
  
  export interface Publisher {
    id: number;
    name: string;
    city: string;
    state: string;
  }
  
  export interface Book {
    isbn: string;
    title: string;
    description: string;
    edition: string;
    category: Category;  // category is now of type Category (not just a number)
    publisher: Publisher;  // publisher is now of type Publisher (not just a number)
  }
  