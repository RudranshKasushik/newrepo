import { CommonModule } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { BookService } from "./book.service";
import { Book } from "./book.model";
import { HttpResponse } from "@angular/common/http";
import { RouterOutlet, RouterLink, ActivatedRoute } from "@angular/router";
import { InventoryService } from "../inventory/inventory.service";



@Component({
    selector: 'book-crud',
    templateUrl: './book.component.html',
    standalone: true,
    imports: [CommonModule, FormsModule,RouterOutlet,RouterLink],
    styleUrls: ['./book.component.css'],
    providers: [BookService]
})
export class BookComponent implements OnInit{
  [x: string]: any;

    book: Book = {isbn: '',title: '',description: '',edition: '',
        category: {id: 0,description: ''},
        publisher: {id: 0,name: '',city: '', state: '' }};
      
    bookList: Book[]=[];
    constructor(private bookService: BookService,private route: ActivatedRoute, private inventoryService: InventoryService) { }
    singleBook: Book | null = null;
    titleSearch: Book | null = null;
    categorySearch: Book[]=[];
    publisherSearch: Book[]=[];
    isbnSearch: string = '';
    updatedBook: Book | null = null;
    searchTerm: any;  // Stores the search term entered
    searchCriteria: any;
    userId: number | null =null;
    isLoggedIn = false;
    inventoryDetails: any[] = [];
    errorMessage: string = '';

    ngOnInit(): void {
      // const userIdParam = this.route.snapshot.paramMap.get('userId');
      // this.userId = userIdParam ? Number(userIdParam) : null;
      this.userId = Number(this.route.snapshot.paramMap.get('userid'));
      console.log(this.userId);

      this.getAllBooks();
  }

  onImageError(event: Event): void {
    const element = event.target as HTMLImageElement;
    element.src = '/assets/img/calculus.jpg'; // Path to the alternate image
  }
  getImagePath(bookTitle: string): string {
    const imageName = "book_img/" +bookTitle.replace(/ /g, '_') + '_book.jpg';
    console.log(imageName)
    return `/assets/img/${imageName}`;
  }
  public onSearchCriteriaChange(searchTerm:any): void {
    this.clearResults();
    switch (this.searchCriteria) {
        case 'title':
            this.getBookByTitle(this.searchTerm);
            break;
        case 'isbn':
            this.getBookById(this.searchTerm);
            break;
        case 'publisherId':
            this.getBookByPublisher(this.searchTerm);
            break;
        case 'categoryId':
            this.getBookByCategory(this.searchTerm);
            break;
        default:
            this.getAllBooks();
    }
}

      // Method to fetch all books
      public getAllBooks(): void {
        this.clearResults();  // Optional: Clear previous results if necessary
        this.bookService.getAllBooks().subscribe(
          (response) => {
            this.bookList = response.body ?? [];  // Ensure bookList is assigned an empty array if null
          },
          (error) => {
            console.error('Error fetching all books:', error);
            alert('Error fetching all books.');
          }
        );
      }
    

      public getBookById(isbn:string){
        this.clearResults();
        this.bookService.getBookById(isbn).subscribe(
          (response: HttpResponse<Book>)=> {
            this.singleBook=response.body;
          },
          (error) => {
            console.error('Error fetching book by ID:', error);
            alert('Error fetching book by ID.');
        }
        )
      }
        // Fetch book by ISBN
  // public getBookById(isbn:string): {
  //   // if (this.isbnSearch) {
  //     this.bookService.getBookById(isbn).subscribe(
  //       (response:HttpResponse<Book>) => {
  //         this.singleBook = response.body;
  //       },
  //       (error) => {
  //         console.error('Error fetching book by ISBN:', error);
  //       }
  //     );
  //   }

  // Fetch books by title
  public getBookByTitle(title:string) {
    this.clearResults();
    this.bookService.getBookByTitle(title).subscribe(
      (response: HttpResponse<Book>)=> {
        this.singleBook=response.body;
      },
      (error) => {
        console.error('Error fetching book by title:', error);
        alert('Error fetching book by title.');
    }
    )
  }

  // Fetch books by category
  public getBookByCategory(categoryId:number){
    this.clearResults();  // Optional: Clear previous results if necessary
    this.bookService.getBookByCategory(categoryId).subscribe(
      (response) => {
        this.bookList = response.body ?? [];  // Ensure bookList is assigned an empty array if null
      },
      (error) => {
        console.error('Error fetching all books:', error);
        alert('Error fetching all books.');
      }
    );
  }

  // Fetch books by publisher
  public getBookByPublisher(publisherId:number) {
    this.clearResults();  // Optional: Clear previous results if necessary
    this.bookService.getBookByPublisher(publisherId).subscribe(
      (response) => {
        this.bookList = response.body ?? [];  // Ensure bookList is assigned an empty array if null
      },
      (error) => {
        console.error('Error fetching all books:', error);
        alert('Error fetching all books.');
      }
    );
  }

  // Update book title
  public updateBookTitle(isbn: string, newTitle: string): void {
    if (isbn && newTitle) {
      this.bookService.updateBookTitle(isbn, newTitle).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book title updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book title:', error);
        }
      );
    }
  }

  // Update book description
  public updateBookDescription(isbn: string, newDesc: string): void {
    if (isbn && newDesc) {
      this.bookService.updateBookDescription(isbn, newDesc).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book description updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book description:', error);
        }
      );
    }
  }

  // Update book category
  public updateBookCategory(isbn: string, newCat: number): void {
    if (isbn && newCat !== null) {
      this.bookService.updateBookCategory(isbn, newCat).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book category updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book category:', error);
        }
      );
    }
  }

  // Update book edition
  public updateBookEdition(isbn: string, newEdition: string): void {
    if (isbn && newEdition) {
      this.bookService.updateBookEdition(isbn, newEdition).subscribe(
        (response) => {
          this.updatedBook = response.body ?? null;
          console.log('Book edition updated:', this.updatedBook);
        },
        (error) => {
          console.error('Error updating book edition:', error);
        }
      );
    }
  }

      // Optional: Clear previous results
      private clearResults(): void {
        this.bookList = [];
      }
    
    
          getCombinedBooks(): Book[] {
        const combined: Book[] = [];

        if (this.bookList.length > 0) {
            combined.push(...this.bookList);
        }

        if (this.singleBook) {
            combined.push(this.singleBook);
        }

        if (this.titleSearch) {
            combined.push(this.titleSearch);
        }

        if (this.categorySearch.length > 0) {
            combined.push(...this.categorySearch);
        }

        if (this.publisherSearch.length > 0) {
            combined.push(...this.publisherSearch);
        }

        return combined;
    }

    getInventoryDetailsByIsbn(isbn:string): void {
      this.inventoryService.getInventoryDetailsByIsbn(isbn).subscribe(
        data => {
          this.inventoryDetails = data;
        },
        error => {
          this.errorMessage = error;
        }
      );
    }


    }