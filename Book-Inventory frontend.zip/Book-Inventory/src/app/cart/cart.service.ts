import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private apiUrl = 'http://localhost:8090/api/shoppingcart';  // Replace with your backend URL

  constructor(private http: HttpClient) {}

  // Add this method in the ShoppingCartService class
  getAllCartDetails(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/all`); // Update with the correct backend endpoint if needed
  }

  addToCart(shoppingCart: any): Observable<string> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  
    // Send the shoppingCart object as the request body
    return this.http.post<string>(`${this.apiUrl}/add/post`, shoppingCart, { headers });
  }
  
  // Get the cart details for a user (GET)
  getCartDetails(userId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/${userId}`);
  }

  // Update the cart: PUT request to update ISBN for a user
  updateCart(userId: number, newIsbn: string): Observable<any> {
    // Pass newIsbn as a URL parameter, not in the body
    return this.http.put<any>(`${this.apiUrl}/${userId}?newIsbn=${newIsbn}`, {});
  }

  // Uncomment if you want to implement remove from cart functionality
  /* removeFromCart(userId: number, isbn: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${userId}/${isbn}`);
  } */
}

























// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
// import { Observable } from 'rxjs';
 
// @Injectable({
//   providedIn: 'root'
// })
// export class CartService {
//   private apiUrl = 'http://localhost:8090/api/shoppingcart';  // Replace with your backend URL
 
//   constructor(private http: HttpClient) {}
 
//   // Add this method in the ShoppingCartService class
//   getAllCartDetails(): Observable<any[]>
//   {
//    return this.http.get<any[]>(`${this.apiUrl}/all`); // Update with the correct backend endpoint
//   }
 
//   addToCart(userId: number, isbn: string): Observable<string> {
//     const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
//     const params = { userId: userId.toString(), isbn: isbn };

//     return this.http.post<string>(`${this.apiUrl}/add`, null, { headers, params });
//   }
//   // Get the cart details for a user (GET)
//   getCartDetails(userId: number): Observable<any[]> {
//     return this.http.get<any[]>(`${this.apiUrl}/${userId}`);
//   }
 
//   // Update the cart: PUT request to update ISBN for a user
//   updateCart(userId: number, newIsbn: string): Observable<any> {
//     const updatedEntry = { newIsbn };  // Only need to pass newIsbn
//     return this.http.put<any>(`${this.apiUrl}/${userId}?newIsbn=${newIsbn}`, updatedEntry);
//   }
 
//  /* removeFromCart(userId: number, isbn: string): Observable<any> {
//     return this.http.delete<any>(`${this.apiUrl}/${userId}/${isbn}`);
//   } */
 
// }