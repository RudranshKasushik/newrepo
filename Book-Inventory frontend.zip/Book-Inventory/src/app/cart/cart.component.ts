import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from './cart.service';
import { LoginService } from '../login/login.service';
import { ActivatedRoute, RouterLink, RouterOutlet } from '@angular/router';
import { PurchaseLogService } from '../purchaselog/purchaselog.service';
 
@Component({
  selector: 'app-shoppingcart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink]
})
export class CartComponent implements OnInit {
  userId: number = 0;   // Default or fetched userId (can be dynamically fetched if needed)
  isbn: string = '';     // ISBN for the current book, entered or selected by the user
  cart: any[] = [];      // To store cart data
  isbnToUpdate: string = '';  // Store ISBN to be updated
  newIsbn: string = '';  // Store the new ISBN value
  showUserIdInput: boolean = false; // Control visibility of user ID input
  showForm: boolean = false; // Show or hide the form for User ID input
  isClicked: boolean = false;  // Track whether the button is clicked
  inventoryId:number = 0;
  message: string = '';  // Message to display success or error
  errorMessage: string = ''; 
  iscart: boolean= false;

  constructor(
    private route: ActivatedRoute,
    private shoppingCartService: CartService,
    private userService: LoginService,
    private purchaseService : PurchaseLogService
  ) {}
 
 
  ngOnInit(): void
  {
    this.userId = Number(this.route.snapshot.paramMap.get('userid'));  // Corrected line
    console.log('User ID from route:', this.userId);  // Verify the value
    this.inventoryId = Number(this.route.snapshot.paramMap.get('inventoryid'));
    console.log("inventoryid " ,this.inventoryId);
    if (this.userId) {
      this.getCartDetails();
    }
    if(this.inventoryId){
      this.iscart=true;
    }
  }
 
    // Method to toggle the visibility of the User ID input form
    toggleForm() {
      this.showForm = !this.showForm;
 
      // Get the "Enter User ID" element and toggle the class
      const element = document.querySelector('.enter-user-id');
      if (element) {
        element.classList.toggle('clicked');  // Toggles the 'clicked' class
      }
    }
 

  getCartDetails(): void {
    if (this.userId) {
      this.shoppingCartService.getCartDetails(this.userId).subscribe(
        (data) => {
          this.cart = data;  // Update cart contents
          console.log('Cart data fetched:', this.cart);
          this.showUserIdInput = false;  // Hide user ID input form after fetching the cart
        },
        (error) => {
          console.error('Error fetching cart details:', error);
        }
      );
    }
  }
 
  // Update the cart: PUT request to update ISBN for the user
  updateCart(userId: number, oldIsbn: string): void {
    if (this.newIsbn && this.newIsbn !== oldIsbn) {
      this.iscart=true;

      this.shoppingCartService.updateCart(userId, this.newIsbn).subscribe(
        (response) => {
          console.log('ISBN updated successfully:', response);
          this.getCartDetails();  // Refresh the cart
          this.isbnToUpdate = '';  // Exit editing mode
          this.newIsbn = '';       // Clear the input field
        },
        (error) => {
          console.error('Error updating ISBN:', error);
        }
      );
    }
    else
    {
      if (!userId || !this.newIsbn.trim()) {
        alert('Please provide a valid User ID and ISBN.');
        return;
      }
     
    }
  }
 
  // Handle the purchase logic
  purchaseNow(): void {
    console.log('Proceeding with purchase:', this.cart);
    this.addPurchaseLog()
  }


  addPurchaseLog(): void {
    if (this.userId && this.inventoryId) {
      alert("Successfully Purchased")
      this.iscart=false;
      this.purchaseService.addPurchaseLog(this.userId, this.inventoryId).subscribe(
        (response) => {
          this.message = 'Purchase log added successfully!';
          this.errorMessage = '';  // Reset error message on success
          alert("Successfully Purchased")
        },
        (error) => {
          this.message = '';  // Reset success message on error
          this.errorMessage = 'Error adding purchase log. Please try again.';
        }
      );
    } else {
      this.errorMessage = 'Please provide valid User ID and Inventory ID.';
    }
  }

}