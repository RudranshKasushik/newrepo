import { Component, OnInit,  ChangeDetectorRef } from '@angular/core';
import { CategoryService } from './category.service';
import { CategoryDTO } from './category.dto';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
 
 
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule]
})
export class CategoryComponent implements OnInit {
  categories: CategoryDTO[] = [];
  filteredCategories: CategoryDTO[] = [];
  searchDescription: string = '';
  newCategory: CategoryDTO = new CategoryDTO();
  categoryForm!: FormGroup;
  showAddForm = false;
  showCategoryList = true; // Default is true to show the table
  showUpdateForm = false;
  selectedCategory: CategoryDTO = new CategoryDTO();
  successMessage: string = ''; // Variable to store success message
 
  constructor(
    private categoryService: CategoryService,
    private formBuilder: FormBuilder,
    private router: Router,
    private cdr: ChangeDetectorRef // Inject ChangeDetectorRef
  ) {}
 
  ngOnInit(): void {
    this.createForm();
  }
 
  // Create the form group
  createForm(): void {
    this.categoryForm = this.formBuilder.group({
      catId: [''],
      catDescription: ['']
    });
  }
 
  // Search categories by description
  onSearch(): void {
    if (this.searchDescription.trim()) {
      this.filteredCategories = this.categories.filter((category) =>
        category.catDescription.toLowerCase().includes(this.searchDescription.toLowerCase())
      );
    } else {
      this.filteredCategories = this.categories;
    }
  }
 
 // Modify your addCategory method to check response directly
addCategory(): void {
  this.categoryService.addCategory(this.newCategory).subscribe(
    (response: string) => {
      if (response === 'Category added successfully') { // Check response directly as a string
        console.log('Category added successfully:', response);
        this.newCategory = new CategoryDTO();
        this.showAddForm = false;
        this.showCategoryList = true;
        alert('Category added successfully');
      }
    },
    (err) => {
      console.error('Error adding category:', err);
      alert('Failed to add category! Please try again.');
    }
  );
}
 
// Update an existing category
updateCategory(): void {
  if (this.categoryForm.valid) {
    const catDescription = this.categoryForm.get('catDescription')?.value;
    const catId = this.categoryForm.get('catId')?.value;
   
    // Call the updateCategory service method
    this.categoryService.updateCategory(catId, catDescription).subscribe(
      (response: string) => {
        // If the update is successful, show success alert
        alert('Category updated successfully');
        console.log('Category updated successfully:', response);
       
        // Reset form and show the category list again
        this.showUpdateForm = false;
        this.categoryForm.reset();
        this.showCategoryList = true; // Show the table after updating
      },
      (err) => {
        console.error('Error updating category:', err);
        alert('Failed to update category! Please try again.');
      }
    );
  }
}
 
 
  // Select category for updating
  selectCategory(category: CategoryDTO): void {
    this.selectedCategory = { ...category };
    this.categoryForm.patchValue({
      catId: this.selectedCategory.catId,
      catDescription: this.selectedCategory.catDescription
    });
    this.showUpdateForm = true;
    this.showAddForm = false;
    this.showCategoryList = false;
  }
 
  // Cancel category update
  cancelUpdate(): void {
    this.showUpdateForm = false;
    this.selectedCategory = new CategoryDTO();
    this.categoryForm.reset();
    this.showCategoryList = true;
  }
 
  // Toggle Add Category form visibility
  toggleAddForm(): void {
    this.showAddForm = !this.showAddForm;
    this.showCategoryList = !this.showAddForm; // If Add form is shown, hide the table;
    this.showUpdateForm = false;
  }
 
  // Toggle Update Category form visibility
  toggleUpdateForm(): void {
    this.showUpdateForm = !this.showUpdateForm;
    this.showAddForm = false;
    this.showCategoryList = false;
  }
 
  // Navigate to books page when category is clicked
  onCategoryClick(category: CategoryDTO): void {
    const encodedDescription = encodeURIComponent(category.catDescription);
    this.router.navigate(['/books', encodedDescription]);
  }
}