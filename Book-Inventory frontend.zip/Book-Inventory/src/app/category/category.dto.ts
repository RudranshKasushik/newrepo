export class CategoryDTO
{
    catId: number = 0;
    catDescription: string = '';
 
    constructor(catId?: number, catDescription?: string)
    {
      this.catId = catId || 0;
      this.catDescription = catDescription || '';
    }
  }