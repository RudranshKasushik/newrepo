import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CategoryDTO } from './category.dto';
 
@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private apiUrl = 'http://localhost:8092/api/category';
 
  constructor(private http: HttpClient) {}
 
  // Add new category
addCategory(category: CategoryDTO): Observable<string> {
  return this.http.post<string>(`${this.apiUrl}/post`, category, { responseType: 'text' as 'json' });
}
 
// Update category
updateCategory(catId: number, description: string): Observable<string> {
  return this.http.put<string>(`${this.apiUrl}/${catId}`, description, { responseType: 'text' as 'json' });
}
 
}