import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root',
})
export class StateService {
  private static url: string = 'http://localhost:8090/api/state';
 
  constructor(private httpClient: HttpClient) {}
 
  // Get All States
  public getAllStates(): Observable<HttpResponse<any[]>> {
    return this.httpClient.get<any[]>(StateService.url + '/all', { observe: 'response' });
  }
 
  // Get State by State Code
  public getStateById(stateCode: string): Observable<HttpResponse<any[]>> {
    return this.httpClient.get<any[]>(StateService.url + '/' + stateCode, { observe: 'response' });
  }
 
  // Add New State
  public addState(state: any): Observable<HttpResponse<any>> {
    return this.httpClient.post(StateService.url + '/post', state, { observe: 'response' });
  }
 
  // Update State Name
  public updateState(stateCode: string, state: any): Observable<HttpResponse<any>> {
    return this.httpClient.put(StateService.url + '/update/name/' + stateCode, state, { observe: 'response' });
  }
}