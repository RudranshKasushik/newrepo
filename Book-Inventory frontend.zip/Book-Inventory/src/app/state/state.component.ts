import { Component } from '@angular/core';
import { StateService } from './state.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
 
@Component({
  selector: 'state-crud',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  providers: [StateService],
})
export class StateComponent {
  state: any = { stateCode: '', stateName: '' };
  stateList: any = [];
  paginatedStates: any = []; // This will hold the states for the current page
  errorMessage: string = '';
 
  currentPage: number = 1;  // Current page for pagination
  pageSize: number = 10;     // Number of states per page
  totalStates: number = 0;  // Total number of states for pagination
  currentAction: string = ''; // Variable to track current action ('allStates' or 'stateById')
 
  constructor(private stateService: StateService) {}
 
  // Add State
  public addState() {
    this.stateService.addState(this.state).subscribe(
      (response) => {
        console.log('State Added:', response.statusText);
        alert('State added successfully!');
        this.getAllStates(); // Refresh the state list
      },
      (error) => {
        alert('Please provide both state code and state name.');
      }
    );
  }
 
  // Get All States
  getAllStates() {
    this.currentAction = 'allStates'; // Set action to 'allStates'
    this.stateService.getAllStates().subscribe(
      (response) => {
        if (response.body) {
          this.stateList = response.body;
          this.totalStates = this.stateList.length;
          this.paginateStates(); // Paginate the fetched data
        } else {
          this.errorMessage = 'No states found.';
          alert(this.errorMessage);
        }
      },
      (error) => {
        this.errorMessage = 'Error fetching states: ' + error.message;
        alert(this.errorMessage);
        console.error(error);
      }
    );
  }
 
  // Get State by ID
  public getStateById() {
    if (!this.state.stateCode) {
      alert('Please Provide State code');
      return;
    }
    this.currentAction = 'stateById'; // Set action to 'stateById'
    this.stateService.getStateById(this.state.stateCode).subscribe(
      (response) => {
        if (!response.body || response.body.length === 0) {
          // If body is null or empty array, show the alert
          alert('State not found for the provided code');
        } else {
          this.stateList = response.body; // Assuming state is returned as an array
        }
      },
      (error) => {
        this.errorMessage = 'Error fetching state: ' + error.message;
        alert(this.errorMessage);
        console.error(error);
      }
    );
  }
 
  // Update State
  updateState() {
    if (this.state.stateCode && this.state.stateName) {
      this.stateService.updateState(this.state.stateCode, this.state).subscribe(
        (response) => {
          console.log('State updated:', response);
          alert('State updated successfully!');
          this.getAllStates(); // Optionally refresh the state list
        },
        (error) => {
          this.errorMessage = 'Error updating state: ' + error.message;
          alert(this.errorMessage);
          console.error(error);
        }
      );
    } else {
      alert('Please provide both state code and state name.');
    }
  }
 
  // Paginate States based on current page and page size
  paginateStates() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.paginatedStates = this.stateList.slice(startIndex, endIndex);
  }
 
  // Pagination Controls
  changePage(page: number) {
    this.currentPage = page;
    this.paginateStates(); // Repaginate the list based on the current page
  }
 
  // Calculate Total Pages
  get totalPages(): number {
    return Math.ceil(this.totalStates / this.pageSize);
  }
}