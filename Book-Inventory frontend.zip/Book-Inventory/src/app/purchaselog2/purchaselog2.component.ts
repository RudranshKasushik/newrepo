import { Component, OnInit } from '@angular/core';
import { PurchaseLog2Service } from './purchaselog2.service';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { InventoryService } from '../inventory/inventory.service';
import { Observable, catchError, forkJoin } from 'rxjs';

@Component({
  selector: 'app-purchaselog2',
  templateUrl: './purchaselog2.component.html',
  styleUrls: ['./purchaselog2.component.css'],
  imports:[CommonModule]
})
export class PurchaseLog2Component implements OnInit {
  purchaseLogs: any[] = [];
  errorMessage: string = '';
  userId: number = 0;
  inventoryIds: number[] = [];
  inventoryResponses: any[] = [];
  extractedData: any[] = [];
  btitle: string = '';

  constructor(
    private route: ActivatedRoute,
    private purchaseLog2Service: PurchaseLog2Service,
    private inventoryService: InventoryService
  ) {}

  ngOnInit(): void {
    // Get the userId from the route
    this.userId = Number(this.route.snapshot.paramMap.get('userid'));
    console.log("this is purchase id", this.userId);
    // Fetch purchase logs if userId exists
    if (this.userId) {
      this.getPurchaseLogs(this.userId);
    } else {
      this.errorMessage = 'User ID not provided!';
    }
  }

  getPurchaseLogs(userid: number): void {
    if (userid) {
      console.log("Calling getPurchaseLogs function");
      this.purchaseLog2Service.getPurchaseLogs(userid).subscribe({
        next: (data) => {
          this.purchaseLogs = data.map((log) => ({
            userId: log.id.userId,
            inventoryId: log.id.inventoryId,
          }));
          this.inventoryIds = data.map((log) => log.id.inventoryId); // Store inventory IDs
          this.errorMessage = ''; // Clear any previous error message
          console.log(this.inventoryIds);
          this.updateInventoryDetails();
        },
        error: (err) => {
          this.purchaseLogs = [];
          this.inventoryIds = [];
          this.errorMessage = 'Failed to fetch purchase logs. Please try again.';
        },
      });
    } else {
      this.errorMessage = 'Invalid User ID!';
    }
  }

  updateInventoryDetails(): void {
    const requests: Observable<any>[] = this.inventoryIds.map(id =>
      this.inventoryService.getInventoryById(id).pipe(
        catchError(error => {
          console.error(`Failed to fetch inventory with ID ${id}`, error);
          return [];
        })
      )
    );

    forkJoin(requests).subscribe({
      next: (responses) => {
        this.inventoryResponses = responses;
        console.log('Inventory responses:', this.inventoryResponses);
        this.extractInventoryData();
      },
      error: (err) => {
        console.error('Failed to fetch inventory details', err);
      }
    });
  }

  extractInventoryData(): void {
    this.extractedData = this.inventoryResponses.map(response => {
      const imagePath = this.getImagePath(response.book.title);
      return {
        title: response.book.title,
        isbn: response.book.isbn,
        edition: response.book.edition,
        imagePath: imagePath
      };
    });
    console.log('Extracted data:', this.extractedData);
  }

  onImageError(event: Event): void {
    const element = event.target as HTMLImageElement;
    element.src = '/assets/img/calculus.jpg'; // Path to the alternate image
  }

  getImagePath(bookTitle: string): string {
    const imageName = "book_img/" + bookTitle.replace(/ /g, '_') + '_book.jpg';
    console.log(imageName);
    return `/assets/img/${imageName}`;
  }
}
