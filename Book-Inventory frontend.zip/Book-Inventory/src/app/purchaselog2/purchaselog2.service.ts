import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class PurchaseLog2Service {
  private apiUrl = 'http://localhost:8090/api/purchaselog';
 
  constructor(private http: HttpClient) {}
 
  // Get Purchase Logs by User ID
  getPurchaseLogs(userId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/${userId}`);
  }
}