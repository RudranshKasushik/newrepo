export interface BookReview {
    isbn: string;
    reviewerid: number;
    rating: number;
    comments: string;
  }