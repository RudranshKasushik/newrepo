import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpResponse } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError, map } from "rxjs/operators";
import { BookReview } from "./bookreview.model";
 
@Injectable({
  providedIn: 'root'
})
export class BookReviewService {
  private static url: string = "http://localhost:8090/api/bookreview"; // Your API URL
  constructor(private httpClient: HttpClient) {}
 
   // 2. Get all reviewers by ISBN
  public getAllReviewersByIsbn(isbn: string): Observable<any[]> {
    return this.httpClient.get<any[]>(`${BookReviewService.url}/${isbn}`)
      .pipe(catchError(this.handleError));
  }
 
  // Error handling method
  private handleError(error: HttpErrorResponse) {
    console.error('Error occurred:', error);
    return throwError(() => new Error(error.message || 'Server error'));
  }

  getReviewsByIsbn(isbn: string): Observable<BookReview[]> {
    return this.httpClient.get<BookReview[]>(`${BookReviewService.url}/reviews/${isbn}`);
  }

}