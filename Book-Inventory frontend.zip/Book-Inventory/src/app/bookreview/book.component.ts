import { Component, OnInit } from '@angular/core';
import { BookReviewService } from './book.service';
import { HttpResponse } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
 
@Component({
  selector: 'app-book-review1',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css'],
  imports: [FormsModule,CommonModule]
})
export class BookReview1Component{
 
  public bookReview = {isbn: '',reviewerid: 0,rating: 0,comments: ''};
 
  public reviewers: any[] = [];
    errorMessage: string | undefined;
  constructor(private bookReviewService: BookReviewService) {}
 
  // 2. Get all reviewers for a given ISBN
  getReviewersByIsbn(): void {
    this.bookReviewService.getAllReviewersByIsbn(this.bookReview.isbn).subscribe(
      (reviewers: any[]) => {
        console.log('Reviewers:', this.reviewers);  // Log to check the response
        this.reviewers = reviewers;
      },
        (error: any) => {
        this.errorMessage = 'Error occurred while fetching reviewers.';
        console.error('Error fetching reviewers:', error);
      }
    );
  }
}