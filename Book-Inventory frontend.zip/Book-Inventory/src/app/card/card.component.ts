import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink, RouterOutlet } from '@angular/router';
import { BookService } from '../book/book.service'; // If needed for fetching book data
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpResponse } from '@angular/common/http';
import { Book } from '../book/book.model';
import { CartService } from '../cart/cart.service';
import { InventoryService } from '../inventory/inventory.service';
import { InventoryDetail } from './inventory.model';
import { BookReviewService } from '../bookreview/book.service';
import { BookReview } from '../bookreview/bookreview.model';

@Component({
  selector: 'app-book-card',
  templateUrl: './card.component.html',
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink],
  styleUrls: ['./card.component.css']
})

export class CardComponent implements OnInit {
  bookIsbn: string | null = null; // Variable to hold the ISBN
  singleBook: Book | null = null; // Holds the book details
  book: Book = { 
    isbn: '', 
    title: '', 
    description: '', 
    edition: '', 
    category: { id: 0, description: '' }, 
    publisher: { id: 0, name: '', city: '', state: '' } 
  };
  userId: number | null = null;
  message: string | null = null;
  inventoryDetails: InventoryDetail[] = [];
  errorMessage: string = '';
  ranksArray: number[] = [];
  selectedCondition: number| null= null;
  price: number | null = null;  // New property for price
  inventoryid: number | null = null;
  inventoryIdsArray: number[] = [];
  inventoryMap: Map<number, number[]> = new Map();
  reviews: BookReview[] = [];
  savedComments: string[] = [];
  islogin: boolean=false;

  // Mapping of conditions to prices
  conditionPrices: { [key: number]: number } = {
    1: 5.00,
    2: 10.00,
    3: 15.00,
    4: 20.00,
    5: 30.00,
    6: 35.00
  };

  rankDescriptions: { [key: number]: string } = {
    1: 'Very Bad',
    2: 'Bad',
    3: 'Poor',
    4: 'Average',
    5: 'Good',
    6: 'Excellent'
  };

  constructor(private route: ActivatedRoute, 
    private bookService: BookService, 
    private cartServe: CartService, 
    private inventoryService: InventoryService,
    private bookreview:BookReviewService) {}

  ngOnInit(): void {
    this.bookIsbn = this.route.snapshot.paramMap.get('isbn');
    const userIdParam = this.route.snapshot.paramMap.get('userId');
    this.userId = userIdParam ? Number(userIdParam) : null;
    console.log(this.userId);
    console.log(this.bookIsbn);
    if (this.bookIsbn) {
      // Fetch the book details if ISBN is available
      this.getBookById(this.bookIsbn);
      this.getInventoryDetailsByIsbn(this.bookIsbn);
      this.getReviewsByIsbn()
    }
    if(this.userId){
      this.islogin=true;
    }
  }


  

  // Fetch book details by ISBN
  public getBookById(isbn: string): void {
    this.bookService.getBookById(isbn).subscribe(
      (response: HttpResponse<Book>) => {
        this.singleBook = response.body; // Assign the fetched book to singleBook
      },
      (error) => {
        console.error('Error fetching book by ID:', error);
        alert('Error fetching book by ID.');
      }
    );
  }

  getImagePath(bookTitle: string): string {
    const imageName = "book_img/" + bookTitle.replace(/ /g, '_') + '_book.jpg';
    console.log(imageName);
    return `/assets/img/${imageName}`;
  }

  onImageError(event: Event): void {
    const element = event.target as HTMLImageElement;
    element.src = '/assets/img/calculus.jpg'; // Path to the alternate image
  }

  addToCart() {
    if (!this.selectedCondition) {
      alert("Please Select condition");
    }
    else if (this.userId && this.bookIsbn) {
      this.islogin=true;
      console.log(this.userId, this.bookIsbn);
      
      // Create a ShoppingCart object to send as the request body
      const shoppingCart = {
        userId: this.userId,
        isbn: this.bookIsbn
      };
      console.log("adding to cart");
      alert("Added to the Cart.");
      this.cartServe.addToCart(shoppingCart).subscribe(
        response => {
          this.message = response;
          alert("Added to the Cart.");
        },
        // error => {
        //   this.message = 'Error adding book to shopping cart';
        //   console.error(error);  // Log the error for debugging
        //   alert("Error adding to the cart. Please try again.");
        // }
      );
    } else {
      this.islogin=false
      alert("Please Login to Buy!");
    }
  }
    
  

  getInventoryDetailsByIsbn(isbn: string): void {
    this.inventoryService.getInventoryDetailsByIsbn(isbn).subscribe(
      (data: InventoryDetail[]) => {
        // Initialize the arrays for ranks and inventory IDs
        this.ranksArray = [];
        this.inventoryIdsArray = [];

        // Loop through the inventory details and collect ranks and inventoryIds
        data.forEach((detail: InventoryDetail) => {
          this.ranksArray.push(detail.ranks);
          this.inventoryIdsArray.push(detail.inventoryId);
        });

        // Log the arrays to check the data
        console.log('Ranks Array:', this.ranksArray);
        console.log('Inventory IDs Array:', this.inventoryIdsArray);
      },
      (error) => {
        console.error('Error fetching inventory details', error);
      }
    );
  }

  updateInventoryId(): void {
    console.log('Selected rank:', this.selectedCondition); // Log selected rank
  
    if (this.selectedCondition !== null) {
      // Ensure selectedCondition is treated as a number
      this.updatePrice();
      const selectedRank = Number(this.selectedCondition);
      
      // Log the ranks array before searching for the index
      console.log('Searching in ranksArray:', this.ranksArray);
  
      // Find the index of the selected rank
      const selectedIndex = this.ranksArray.indexOf(selectedRank);
  
      // Use the index to get the corresponding inventory ID
      if (selectedIndex !== -1) {
        this.inventoryid = this.inventoryIdsArray[selectedIndex];
        console.log('Selected Inventory ID:', this.inventoryid);
      } else {
        console.error('Selected rank not found in ranksArray');
      }
    } else {
      console.error('No rank selected');
    }
  }
  


  // getInventoryDetailsByIsbn(isbn: string): void {
  //   this.inventoryService.getInventoryDetailsByIsbn(isbn).subscribe(
  //     (data: InventoryDetail[]) => {
  //       // Initialize the inventory map
  //       this.inventoryMap.clear();
  
  //       // Loop through the inventory details and map ranks to inventoryIds
  //       data.forEach((detail: InventoryDetail) => {
  //         if (!this.inventoryMap.has(detail.ranks)) {
  //           this.inventoryMap.set(detail.ranks, []);
  //         }
  //         this.inventoryMap.get(detail.ranks)?.push(detail.inventoryId);
  //       });
  
  //       // Create the array of unique ranks and inventory IDs
  //       this.uniqueRanksArray = Array.from(this.inventoryMap.keys());
  //       this.inventoryArray = Array.from(new Set(data.map(detail => detail.inventoryId))); // To remove duplicates
  
  //       console.log('Unique Ranks Array:', this.uniqueRanksArray);
  //       console.log('Inventory Array:', this.inventoryArray);
  //     },
  //     (error) => {
  //       console.error('Error fetching inventory details', error);
  //     }
  //   );
  // }
  
  updatePrice(): void {
    if (this.selectedCondition !== null) {
      this.price = this.conditionPrices[this.selectedCondition];
      console.log(`Price for selected condition (${this.selectedCondition}): ${this.price}`);
  
      // Call updateInventoryIdBasedOnCondition to set the inventory ID
      // this.updateInventoryIdBasedOnCondition();
    } else {
      this.price = null;
      // this.inventoryid = null;
    }
  }
  

  // updateInventoryIdBasedOnCondition(): void {
  //   if (this.selectedCondition !== null) {
  //     console.log("updateInventoryIdBasedOnCondition called");
  
  //     const index = this.uniqueRanksArray.indexOf(this.selectedCondition);
  //     console.log('Index found for selected condition:', index);
  
  //     if (index !== -1 && index < this.inventoryArray.length) {
  //       console.log("Setting inventory ID based on condition position");
  //       // Set the inventory ID based on the selected condition's position
  //       this.inventoryid = this.inventoryArray[index];
  //       console.log(`Inventory ID set to: ${this.inventoryid}`);
  //     } else {
  //       console.log("Condition not found in ranks or index out of bounds");
  //       this.inventoryid = null;
  //     }
  //   }
  // }
  
  

  getReviewsByIsbn(): void {
    if (this.bookIsbn) {
      this.bookreview.getReviewsByIsbn(this.bookIsbn).subscribe(
        (data) => {
          this.reviews = data;
          // Extracting and saving the comments
          this.savedComments = data.map((review: any) => review.comments);
          console.log(this.savedComments); // Display saved comments
  
          // Optional: If you want to process the comments further
          // For example, storing them in a database or handling them in another way
        },
        (error) => {
          console.error('There was an error!', error);
        }
      );
    }
  }
  


}
