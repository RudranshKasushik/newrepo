export interface InventoryDetail {
    inventoryId: number;
    ranks: number;
  }
  